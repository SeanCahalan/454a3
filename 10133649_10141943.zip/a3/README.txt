Sean Cahalan
13sc77@queensu.ca
10133649

Henley Chiu
13hc37@queensu.ca
10141943

Screenshots show the effects on the test files, ran into difficulties with showing them in a proper scene.